# Fantom Gas Price Extension
Displays the latest gas price provided by [FTMScan](https://ftmscan.com/).

To install [click here](TBD).

## Contributing
Feel free to contribute any code or fork this project. If you have ideas, open up an issue or contact me via email (nieldlr@gmail.com) as well.

## Donating
If you found this extension useful, please consider [donating](https://etherscan.io/address/0x229e63b972f476b75987b03b3dc96be5dd0cf80b). Eth is preferred, but any token is welcome.